# InNeed
Job Portal For Physically Disabled People
InNeed is a web based job search portal specially designed for physically
challenged. We have used HTML, CSS, JavaScript, Bootstrap, NodeJS, PHP,
MySql. In order to ease the experience for the disabled we have provided gesture
control to navigate across the website. This responsive and dynamic website will
help the needy physically disabled get a job and get a chance to live an
independent life. While on the other hand, the employer will get a needy and
hardworking employee.
The web portal includes login, signup, and register options for both job seekers and
employers. For employers the form asks company name and other details to
register. One the registration is done the employer is redirected to the employer
dashboard and gets an option to list jobs.
The Employer can list their job as per their hirings. On the other side, we ask for
educational details for the job seeker to register, after the registration the job seeker
is redirected to their dashboard where they can apply for different job openings as
per their likings. InNeed being a fast and responsive website it makes it easy for
both the employer and job seeker to use.

Demo :https://inneed-job-portal.000webhostapp.com/index.php

![image](https://user-images.githubusercontent.com/53631121/166121515-c716df6e-afa5-4619-aba5-33c42e4305b0.png)
![image](https://user-images.githubusercontent.com/53631121/166121520-e7b622f9-fcf4-4ae4-87fb-bc093bcb4382.png)
